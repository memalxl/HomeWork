const startButton = document.querySelector('.start-now');

startButton.addEventListener('mouseenter', () => {
    startButton.style.transform = 'scale(1.05)';
});

startButton.addEventListener('mouseleave', () => {
    startButton.style.transform = 'scale(1)';
});
